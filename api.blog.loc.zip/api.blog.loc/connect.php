<?php
$connect = mysqli_connect('localhost','root','root','api_tester');
//$connect = mysqli_connect('https://api.blog.kroxdev.ru','krox853_test','Q8K-SZ6','krox853_api_tester');
//printf($connect->host_info);