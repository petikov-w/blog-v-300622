<?php
//die(print_r($_POST));
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Credentials: true');
header('Content-type: json/application');
//$postsList = [];
require 'connect.php';
require 'functions.php';
$method =$_SERVER['REQUEST_METHOD'];
$q = $_GET['q'];
$params = explode('/', $q);
$type = $params[0];
if (isset($params[1])) $id = $params[1];

if($method==='GET') {
    if($type==='posts') {
        if (isset($id)) {
            getPost($connect, $id);
        } else {
            getPosts($connect);
        }
}
    if($type==='settings') {
        getSettings($connect);
    }

} elseif ($method==='POST') {
    if($type==='posts') {
        addPost($connect, $_POST);
    }

} elseif ($method==='PATCH') {
    if($type==='posts') {
        if (isset($id)) {
            $data = json_decode(file_get_contents('php://input'),true);
            updatePost($connect, $id, $data);
        }
    }
    if($type==='settings') {
        $data = json_decode(file_get_contents('php://input'),true);
        updateSettings($connect, $data);
    }
}


